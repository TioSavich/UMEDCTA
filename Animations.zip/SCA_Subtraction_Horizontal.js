(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"SCA_Subtraction_Horizontal_atlas_1", frames: [[1784,183,208,74],[320,603,137,38],[1892,371,149,110],[459,603,137,38],[1856,483,149,110],[0,563,360,38],[460,371,355,110],[362,563,360,38],[817,371,355,110],[0,418,413,38],[0,0,228,416],[0,523,413,38],[230,0,228,416],[1724,595,158,38],[2009,0,19,63],[1790,0,167,181],[1884,595,158,38],[2009,65,19,63],[460,259,372,110],[834,259,372,110],[1208,259,372,110],[1582,259,372,110],[1216,0,285,145],[586,483,499,38],[1503,0,285,145],[1270,491,499,38],[985,603,100,38],[724,563,213,38],[1724,635,100,38],[939,563,213,38],[598,603,137,38],[1270,531,126,110],[737,603,137,38],[1398,531,126,110],[460,0,376,110],[838,0,376,110],[1270,371,620,38],[1270,411,620,38],[415,523,365,38],[1174,371,94,317],[782,523,365,38],[1526,531,97,135],[0,603,158,38],[1625,531,97,135],[160,603,158,38],[1959,0,48,179],[1032,147,374,110],[1408,147,374,110],[460,112,284,145],[746,112,284,145],[1270,451,584,38],[0,483,584,38],[1724,531,107,38],[876,603,107,38]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_106 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["SCA_Subtraction_Horizontal_atlas_1"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



// stage content:
(lib.SCA_Subtraction_Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [1,16];
	// timeline functions:
	this.frame_1 = function() {
		this.stop(); // Stop the timeline at the first frame
		
		// Function to handle click events
		this.onClick = function (e) {
		    // Check if the current frame is the last one
		    if (this.currentFrame < this.totalFrames - 1) {
		        this.gotoAndStop(this.currentFrame + 1); // Advance to the next frame
		    } else {
		        this.gotoAndStop(0); // If at the last frame, loop back to the first frame
		    }
		}.bind(this);
		
		// Add the click event listener to the canvas
		canvas.addEventListener('click', this.onClick);
	}
	this.frame_16 = function() {
		this.stop(); // Stop the timeline at the first frame
		
		// Function to handle click events
		this.onClick = function (e) {
		    // Check if the current frame is the last one
		    if (this.currentFrame < this.totalFrames - 1) {
		        this.gotoAndStop(this.currentFrame + 1); // Advance to the next frame
		    } else {
		        this.gotoAndStop(0); // If at the last frame, loop back to the first frame
		    }
		}.bind(this);
		
		// Add the click event listener to the canvas
		canvas.addEventListener('click', this.onClick);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(15).call(this.frame_16).wait(1));

	// Layer_25
	this.instance = new lib.CachedBmp_50();
	this.instance.setTransform(86.9,10.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_51();
	this.instance_1.setTransform(86.9,10.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));

	// Step_0
	this.instance_2 = new lib.CachedBmp_52();
	this.instance_2.setTransform(86.9,36.2,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_53();
	this.instance_3.setTransform(86.9,36.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},15).wait(1));

	// Layer_6
	this.instance_4 = new lib.CachedBmp_54();
	this.instance_4.setTransform(88.8,70.8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_55();
	this.instance_5.setTransform(88.8,70.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},14).wait(1));

	// Layer_14
	this.instance_6 = new lib.CachedBmp_56();
	this.instance_6.setTransform(409.45,86.75,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_57();
	this.instance_7.setTransform(409.45,86.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},3).to({state:[{t:this.instance_7}]},13).wait(1));

	// Layer_15
	this.instance_8 = new lib.CachedBmp_60();
	this.instance_8.setTransform(208.9,146.9,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_59();
	this.instance_9.setTransform(265.65,148.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_61();
	this.instance_10.setTransform(190.45,61.8,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_63();
	this.instance_11.setTransform(208.9,146.9,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_62();
	this.instance_12.setTransform(265.65,148.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8}]},4).to({state:[{t:this.instance_10},{t:this.instance_12},{t:this.instance_11}]},12).wait(1));

	// Step_2
	this.instance_13 = new lib.CachedBmp_67();
	this.instance_13.setTransform(217.2,61.8,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_64();
	this.instance_14.setTransform(409.45,151.4,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_66();
	this.instance_15.setTransform(409.45,151.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14},{t:this.instance_13}]},5).to({state:[{t:this.instance_15},{t:this.instance_13}]},11).wait(1));

	// Layer_16
	this.instance_16 = new lib.CachedBmp_68();
	this.instance_16.setTransform(86.9,221.8,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_69();
	this.instance_17.setTransform(86.9,221.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},6).to({state:[{t:this.instance_17}]},10).wait(1));

	// Layer_17
	this.instance_18 = new lib.CachedBmp_70();
	this.instance_18.setTransform(409.45,241.35,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_71();
	this.instance_19.setTransform(409.45,241.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},7).to({state:[{t:this.instance_19}]},9).wait(1));

	// Layer_19
	this.instance_20 = new lib.CachedBmp_73();
	this.instance_20.setTransform(7.3,241.35,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_72();
	this.instance_21.setTransform(16.85,262.5,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_75();
	this.instance_22.setTransform(7.3,241.35,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_74();
	this.instance_23.setTransform(16.85,262.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21},{t:this.instance_20}]},8).to({state:[{t:this.instance_23},{t:this.instance_22}]},8).wait(1));

	// Layer_18
	this.instance_24 = new lib.CachedBmp_77();
	this.instance_24.setTransform(134.05,241.35,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_76();
	this.instance_25.setTransform(116,262.5,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_79();
	this.instance_26.setTransform(134.05,241.35,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_78();
	this.instance_27.setTransform(116,262.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_25},{t:this.instance_24}]},9).to({state:[{t:this.instance_27},{t:this.instance_26}]},7).wait(1));

	// Layer_13
	this.instance_28 = new lib.CachedBmp_81();
	this.instance_28.setTransform(89.05,348.05,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_80();
	this.instance_29.setTransform(86.95,317.75,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_83();
	this.instance_30.setTransform(89.05,348.05,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_82();
	this.instance_31.setTransform(86.95,317.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29},{t:this.instance_28}]},10).to({state:[{t:this.instance_31},{t:this.instance_30}]},6).wait(1));

	// Layer_20
	this.instance_32 = new lib.CachedBmp_85();
	this.instance_32.setTransform(409.45,329.4,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_84();
	this.instance_33.setTransform(409.45,329.4,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_87();
	this.instance_34.setTransform(409.45,329.4,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_86();
	this.instance_35.setTransform(409.45,329.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_33},{t:this.instance_32}]},11).to({state:[{t:this.instance_35},{t:this.instance_34}]},5).wait(1));

	// Step_4
	this.instance_36 = new lib.CachedBmp_93();
	this.instance_36.setTransform(83.3,340.4,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_89();
	this.instance_37.setTransform(34.4,435.15,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_88();
	this.instance_38.setTransform(122.25,429.95,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_92();
	this.instance_39.setTransform(34.4,435.15,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_91();
	this.instance_40.setTransform(122.25,429.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_38},{t:this.instance_37},{t:this.instance_36}]},12).to({state:[{t:this.instance_40},{t:this.instance_39},{t:this.instance_36}]},4).wait(1));

	// Step_5
	this.instance_41 = new lib.CachedBmp_95();
	this.instance_41.setTransform(409.45,445.2,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_94();
	this.instance_42.setTransform(98.6,340.4,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_97();
	this.instance_43.setTransform(409.45,445.2,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_96();
	this.instance_44.setTransform(98.6,340.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_42},{t:this.instance_41}]},13).to({state:[{t:this.instance_44},{t:this.instance_43}]},3).wait(1));

	// Step_6
	this.instance_45 = new lib.CachedBmp_99();
	this.instance_45.setTransform(87.05,552.95,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_98();
	this.instance_46.setTransform(409.45,550.75,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_101();
	this.instance_47.setTransform(87.05,552.95,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_100();
	this.instance_48.setTransform(409.45,550.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_46},{t:this.instance_45}]},14).to({state:[{t:this.instance_48},{t:this.instance_47}]},2).wait(1));

	// Layer_10
	this.instance_49 = new lib.CachedBmp_103();
	this.instance_49.setTransform(16.85,572.35,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_102();
	this.instance_50.setTransform(16.85,589.95,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_105();
	this.instance_51.setTransform(16.85,572.35,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_104();
	this.instance_52.setTransform(16.85,589.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_50},{t:this.instance_49}]},15).to({state:[{t:this.instance_52},{t:this.instance_51}]},1).wait(1));

	// Layer_1
	this.instance_53 = new lib.CachedBmp_106();
	this.instance_53.setTransform(208.7,584.9,0.5,0.5);
	this.instance_53._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(16).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(313.3,406.5,302.7,238.5);
// library properties:
lib.properties = {
	id: '284A4F1BEC8E479DAABD2DEB658B7211',
	width: 612,
	height: 792,
	fps: 1,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/SCA_Subtraction_Horizontal_atlas_1.png", id:"SCA_Subtraction_Horizontal_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['284A4F1BEC8E479DAABD2DEB658B7211'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;