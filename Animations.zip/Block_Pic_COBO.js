(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Block_Pic_COBO_atlas_1", frames: [[1624,408,32,32],[1528,0,199,202],[1252,204,86,38],[1443,596,20,32],[1658,408,32,32],[270,726,267,202],[1340,204,86,38],[1465,596,20,32],[1624,442,32,32],[1448,204,265,202],[1448,408,86,38],[1487,596,20,32],[1658,442,32,32],[816,669,267,202],[0,0,1250,259],[1509,596,20,32],[1443,528,32,32],[1252,0,274,202],[1536,408,86,38],[1531,596,20,32],[1477,528,32,32],[274,522,269,202],[1448,448,86,38],[1553,596,20,32],[1511,528,32,32],[1085,669,266,202],[1575,596,20,32],[1545,528,32,32],[1353,669,266,202],[1536,448,86,38],[1597,596,20,32],[1579,528,32,32],[545,669,269,202],[0,261,1166,259],[1619,596,20,32],[1613,528,32,32],[0,726,268,202],[1443,488,70,38],[1443,562,32,32],[1477,562,32,32],[1168,465,273,202],[1515,488,70,38],[1511,562,32,32],[1545,562,32,32],[1168,261,278,202],[1587,488,70,38],[1579,562,32,32],[1613,562,32,32],[0,522,272,202]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_155 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_151 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_150 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_149 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_148 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_147 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_146 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_145 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_144 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_143 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_142 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_141 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_140 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_139 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_138 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_137 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_136 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_135 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_134 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_133 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_132 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_131 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_130 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["Block_Pic_COBO_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



// stage content:
(lib.Block_Pic_COBO = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		this.stop(); // Stop the timeline at the first frame
		
		// Function to handle click events
		this.onClick = function (e) {
		    // Check if the current frame is the last one
		    if (this.currentFrame < this.totalFrames - 1) {
		        this.gotoAndStop(this.currentFrame + 1); // Advance to the next frame
		    } else {
		        this.gotoAndStop(0); // If at the last frame, loop back to the first frame
		    }
		}.bind(this);
		
		// Add the click event listener to the canvas
		canvas.addEventListener('click', this.onClick);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// _
	this.instance = new lib.CachedBmp_109();
	this.instance.setTransform(120.4,95.8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_108();
	this.instance_1.setTransform(40.55,95.8,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_107();
	this.instance_2.setTransform(18,116,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(30));

	// _
	this.instance_3 = new lib.CachedBmp_110();
	this.instance_3.setTransform(158,143.45,0.5,0.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(29));

	// _
	this.instance_4 = new lib.CachedBmp_113();
	this.instance_4.setTransform(308.65,95.8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_112();
	this.instance_5.setTransform(225.75,95.8,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_111();
	this.instance_6.setTransform(198,115.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},2).wait(28));

	// _
	this.instance_7 = new lib.CachedBmp_114();
	this.instance_7.setTransform(342,141.45,0.5,0.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(3).to({_off:false},0).wait(27));

	// _
	this.instance_8 = new lib.CachedBmp_117();
	this.instance_8.setTransform(496.35,95.8,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_116();
	this.instance_9.setTransform(417,95.8,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_115();
	this.instance_10.setTransform(383.5,113,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8}]},4).wait(26));

	// _
	this.instance_11 = new lib.CachedBmp_118();
	this.instance_11.setTransform(520,141.45,0.5,0.5);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(5).to({_off:false},0).wait(25));

	// _
	this.instance_12 = new lib.CachedBmp_121();
	this.instance_12.setTransform(682.55,95.8,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_120();
	this.instance_13.setTransform(602.65,95.8,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_119();
	this.instance_14.setTransform(559,113,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12}]},6).wait(24));

	// _
	this.instance_15 = new lib.CachedBmp_122();
	this.instance_15.setTransform(28,229,0.5,0.5);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(7).to({_off:false},0).wait(23));

	// _
	this.instance_16 = new lib.CachedBmp_125();
	this.instance_16.setTransform(199.2,292.65,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_124();
	this.instance_17.setTransform(105.1,292.65,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_123();
	this.instance_18.setTransform(76.5,309,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18},{t:this.instance_17},{t:this.instance_16}]},8).wait(22));

	// _0
	this.instance_19 = new lib.CachedBmp_126();
	this.instance_19.setTransform(215,339.45,0.5,0.5);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(9).to({_off:false},0).wait(21));

	// _1
	this.instance_20 = new lib.CachedBmp_129();
	this.instance_20.setTransform(378.7,292.65,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_128();
	this.instance_21.setTransform(282.45,292.65,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_127();
	this.instance_22.setTransform(256,309,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_132();
	this.instance_23.setTransform(378.7,292.65,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_131();
	this.instance_24.setTransform(282.45,292.65,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_130();
	this.instance_25.setTransform(256,309,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20}]},10).to({state:[{t:this.instance_25},{t:this.instance_24},{t:this.instance_23}]},19).wait(1));

	// _2
	this.instance_26 = new lib.CachedBmp_133();
	this.instance_26.setTransform(396,354.45,0.5,0.5);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(11).to({_off:false},0).wait(19));

	// _3
	this.instance_27 = new lib.CachedBmp_136();
	this.instance_27.setTransform(562.05,292.65,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_135();
	this.instance_28.setTransform(480.1,292.65,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_134();
	this.instance_29.setTransform(438.5,309,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29},{t:this.instance_28},{t:this.instance_27}]},12).wait(18));

	// _4
	this.instance_30 = new lib.CachedBmp_137();
	this.instance_30.setTransform(572,349.45,0.5,0.5);
	this.instance_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(13).to({_off:false},0).wait(17));

	// _5
	this.instance_31 = new lib.CachedBmp_140();
	this.instance_31.setTransform(744.65,292.65,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_139();
	this.instance_32.setTransform(656.5,292.65,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_138();
	this.instance_33.setTransform(618,309,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_33},{t:this.instance_32},{t:this.instance_31}]},14).wait(16));

	// _6
	this.instance_34 = new lib.CachedBmp_141();
	this.instance_34.setTransform(10,420,0.5,0.5);
	this.instance_34._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(15).to({_off:false},0).wait(15));

	// _7
	this.instance_35 = new lib.CachedBmp_144();
	this.instance_35.setTransform(182.95,484.85,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_143();
	this.instance_36.setTransform(97.7,484.85,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_142();
	this.instance_37.setTransform(60.5,502,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_37},{t:this.instance_36},{t:this.instance_35}]},16).wait(14));

	// _8
	this.instance_38 = new lib.CachedBmp_145();
	this.instance_38.setTransform(197,542.45,0.5,0.5);
	this.instance_38._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(17).to({_off:false},0).wait(13));

	// _9
	this.instance_39 = new lib.CachedBmp_148();
	this.instance_39.setTransform(366.7,484.85,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_147();
	this.instance_40.setTransform(281.75,484.85,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_146();
	this.instance_41.setTransform(244.5,502,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_41},{t:this.instance_40},{t:this.instance_39}]},18).wait(12));

	// _0
	this.instance_42 = new lib.CachedBmp_149();
	this.instance_42.setTransform(396,544.45,0.5,0.5);
	this.instance_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(19).to({_off:false},0).wait(11));

	// _1
	this.instance_43 = new lib.CachedBmp_152();
	this.instance_43.setTransform(573.15,484.85,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_151();
	this.instance_44.setTransform(489.45,484.85,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_150();
	this.instance_45.setTransform(450.5,502,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_45},{t:this.instance_44},{t:this.instance_43}]},20).wait(10));

	// _2
	this.instance_46 = new lib.CachedBmp_153();
	this.instance_46.setTransform(599,542.45,0.5,0.5);
	this.instance_46._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(21).to({_off:false},0).wait(9));

	// _3
	this.instance_47 = new lib.CachedBmp_155();
	this.instance_47.setTransform(695.35,484.85,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_154();
	this.instance_48.setTransform(653.5,504,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_48},{t:this.instance_47}]},22).wait(8));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(406,401.8,349,203.2);
// library properties:
lib.properties = {
	id: '039A5DF15AC54965B68A1B4B75E46E71',
	width: 792,
	height: 612,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Block_Pic_COBO_atlas_1.png", id:"Block_Pic_COBO_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['039A5DF15AC54965B68A1B4B75E46E71'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;